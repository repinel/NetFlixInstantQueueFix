// Copyright 2011 Roque Pinel.
//
// This file is part of Netflix InstantQueue Fix GM.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// ==UserScript==
// @name          Netflix InstantQueue Fix GM
// @namespace     http://pinel.cc
// @description   Add Instant Queue support to Netflix outside US.
// @include       http://*.netflix.com/*
// @include       https://*.netflix.com/*
// @include       http://movies.netflix.com/WiHome
// @include       http://movies.netflix.com/WiMovie/*
// @require       http://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js
// ==/UserScript==

$(document).ready(function()
{
	console.log('[NetFlix InstantQueue Fix] Loading...');

	var nav = $('#hd #navigation .navigation, #hd #navigation .nav-menu');

	if (nav.length)
	{
		if (nav.find('#nav-queue').length)
		{
			console.log('[NetFlix InstantQueue Fix] Instant Queue already exists.');
		}
		else
		{
			console.log(window.netflix);
			console.log('[NetFlix InstantQueue Fix] Appending Instant Queue to the navigation.');
			nav.append('<li id="nav-queue" class="nav-item"><a title="Instant Queue" href="http://movies.netflix.com/Queue?qtype=ED"><span>Instant Queue</span></a></li>');
		}
	}
	else
	{
		console.log('[NetFlix InstantQueue Fix] No navigation.');
	}

	var element = $('.boxShot');

	// home page
	if (element.length)
	{
		element.live('mouseenter', onMouseEnterBoxShot);
	}

	var element = $('#mdp-actions .mltBtn.btnWrap, #sdp-actions .mltBtn.btnWrap');

	// if we are one the movie or serie page and the link wasn't already added
	if (element.length && element.find('#NetflixInstantQueueFix').length == 0)
	{
		var id = getId();
		var trkid = getTrkid();
		var authURL = getAuthURL();

		// if we have all the information needed
		if (id && trkid && authURL)
		{
			var addURL = 'http://movies.netflix.com/AddToQueue?movieid=' + id + '&qtype=ED&trkid=' + trkid + '&authURL=' + authURL + '&section=WATCHNOW';

			var addItemString = '<a class="btn btn-50 addlk btn-ED-50 btn-rent btn-ED-rent" data-vid="" href='
				+ addURL + '" id="NetflixInstantQueueFix"><span class="inr">Add to Instant Queue</span></a>';

			element.append(addItemString);
		}
	}
});

function onMouseEnterBoxShot()
{
	// workaround to wait until we have the information
	window.setTimeout(function(){changeBobMovie();}, 1000);
}

function changeBobMovie()
{
	if ($('.bobContent').length)
	{
		var id = getId();
		var trkid = getTrkid();
		var authURL = getAuthURL();

		var bobMovieActions = $('.bobContent .bobMovieContent .midBob .bobMovieActions')

		// if we have all the information needed and the link wasn't already added
		if (id && trkid && authURL && bobMovieActions.length && bobMovieActions.find('#NetflixInstantQueueFix').length == 0)
		{
			var addURL = 'http://movies.netflix.com/AddToQueue?movieid=' + id + '&qtype=ED&trkid=' + trkid + '&authURL=' + authURL + '&section=WATCHNOW';

			var addItemString = '<span class="btnWrap mltBtn mltBtn-s186"><a data-vid="'
				+ id + '" class="btn btn-186 addlk btn-ED-186 btn-rent btn-ED-rent " href="'
				+ addURL + '" id="NetflixInstantQueueFix"><span class="inr ">Instant Queue</span></a></span>';

			bobMovieActions.append(addItemString);
		}
	}
}

function getId()
{
	// home page
	var element = $('.bobContent .bobMovieContent .readMore');

	var id = null;

	if (element.length != 0)
	{
		var id = element.attr('href').match(/\/(\d*)\?/);

		id = id.length > 1 ? id[1] : null;
	}
	else
	{
		// movie or serie page
		element = $('#sdp-actions .btnWrap .watchlk, #mdp-actions .btnWrap .watchlk');

		if (element.length != 0)
		{
			id = element.attr('href').match(/movieid=(\d*)/);

			id = id.length > 1 ? id[1] : null;
		}
	}

	return id;
}

function getTrkid()
{
	// home page, movie or serie page
	var element = $('.bobContent .bobMovieContent .readMore, #sdp-actions .btnWrap .watchlk, #mdp-actions .btnWrap .watchlk');

	var trkid = null;

	if (element.length != 0)
	{
		trkid = element.attr('href').match(/trkid=(\d*)/);

		trkid = trkid.length > 1 ? trkid[1] : null;
	}

	return trkid;
}

function getAuthURL()
{
	var element = $('#profiles-menu .last-of-type a');

	if (element.length == 0)
		return null;

	var authURL = element.attr('href').match(/authURL=(.*)/);

	return authURL.length > 1 ? authURL[1] : null;
}

// EOF

