// Copyright 2011 Roque Pinel.
//
// This file is part of NetFlix InstantQueue Fix.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

$(document).ready(function()
{
	var id = getId();
	var trkid = getTrkid();
	var authURL = getAuthURL();

	var element = $('#mdp-actions .mltBtn.btnWrap, #sdp-actions .mltBtn.btnWrap');

	// if we have all the information needed and the link wasn't already added
	if (id && trkid && authURL && element.length && element.find('NetFlixInstantQueueFix').length == 0)
	{
		var addURL = 'http://movies.netflix.com/AddToQueue?movieid=' + id + '&qtype=ED&trkid=' + trkid + '&authURL=' + authURL + '&section=WATCHNOW';

		var addItemString = '<a class="btn btn-50 addlk btn-ED-50 btn-rent btn-ED-rent" data-vid="" href='
			+ addURL + '" id="NetFlixInstantQueueFix"><span class="inr">Add to Instant Queue</span></a>';

		element.append(addItemString);
	}
});

function getId()
{
	var element = $('#sdp-actions .btnWrap .watchlk, #mdp-actions .btnWrap .watchlk');

	if (element.length == 0)
		return null;

	var id = element.attr('href').match(/movieid=(\d*)/);

	return id.length > 1 ? id[1] : null;
}

function getTrkid()
{
	var element = $('#sdp-actions .btnWrap .watchlk, #mdp-actions .btnWrap .watchlk');

	if (element.length == 0)
		return null;

	var trkid = element.attr('href').match(/trkid=(\d*)/);

	return trkid.length > 1 ? trkid[1] : null;
}

function getAuthURL()
{
	var element = $('#profiles-menu .last-of-type a');

	if (element.length == 0)
		return null;

	var authURL = element.attr('href').match(/authURL=(.*)/);

	return authURL.length > 1 ? authURL[1] : null;
}

